﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cat1
{
    class Program
    {
        static void Main (string [ ] args)
        {
            Cat1 murzik = new Cat1("Мурзик", 4.0);
            Cat1 barsik = new Cat1("Барсик", 8.0);

            murzik.Meow( );
            barsik.Meow( );

            barsik.Name = "Барсик";
            barsik.Meow( );
            barsik.Name = "1234";
            barsik.Meow( );
            Console.ReadKey( );
        }
    }
}
