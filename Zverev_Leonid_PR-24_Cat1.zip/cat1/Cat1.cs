﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cat1
{
    class Cat1
    {
        private string name;
        private double weight;
            public string Name
            {
                get 
            {
                return name;
            }
            set {
                bool OnlyLetter = true;
                foreach ( var ch in value )
                {
                    if ( !char.IsLetter(ch) )
                    {
                        OnlyLetter = false;
                    }
                }
                if ( OnlyLetter )
                {
                    name = value;
                }
                else {
                    Console.WriteLine($"{value} - не правильное имя!");
                }
            }
        }
        public double Weight {
            get 
            {
                return weight;
            }
            set {
                if ( value < 1 && value < 20 )
                {
                    Console.WriteLine("Неправильный вес!");
                }
                else {
                    weight = value;
                }
            }
        }
        public Cat1 (string CatName, double CatWeight) 
        {
            Name = CatName;
            Weight = CatWeight;
        }

        public void Meow () {
            Console.WriteLine($"{name}: МЯЯЯЯЯУ!!!!");
            Console.WriteLine($"Вес кота по имени {name} - {weight}");
            Console.WriteLine("--------------------");
        }
    }
}
